/* IdeaSoft Hediye Paketi - Midas Dijital */

(function () {
    "use strict";

    if (window.midasGiftPackageInstalled) return;
    window.midasGiftPackageInstalled = true;

    var giftPending = false;

    function updateComponent(component) {
        var toggle = component.querySelector("[data-gift-toggle]");
        var choices = component.querySelectorAll('.md-gift-package__choice');

        component.classList.toggle("is-open", Boolean(toggle && toggle.checked));

        choices.forEach(function (choice) {
            var input = choice.querySelector('input[name="giftProducts"]');
            choice.classList.toggle("is-selected", Boolean(input && input.checked));
        });
    }

    document.addEventListener("change", function (event) {
        var component = event.target.closest("[data-gift-package]");
        if (component) updateComponent(component);
    });

    document.addEventListener("click", function (event) {
        var viewLink = event.target.closest(".md-gift-package__view");
        if (viewLink) {
            event.stopPropagation();
            return;
        }

        var mainButton = event.target.closest('.add-to-cart-button[data-context="detail"]');
        if (!mainButton || mainButton.hasAttribute("data-gift-cart-trigger")) return;

        var component = document.querySelector("[data-gift-package]");
        if (!component) return;

        var toggle = component.querySelector("[data-gift-toggle]");
        var selected = component.querySelector('input[name="giftProducts"]:checked');
        var trigger = component.querySelector("[data-gift-cart-trigger]");

        if (!toggle || !toggle.checked || !selected || !trigger || giftPending) return;

        giftPending = true;
        trigger.setAttribute("data-product-id", selected.value);

        window.setTimeout(function () {
            trigger.click();

            window.setTimeout(function () {
                giftPending = false;
            }, 1200);
        }, 700);
    }, true);

    document.querySelectorAll("[data-gift-package]").forEach(updateComponent);
})();
